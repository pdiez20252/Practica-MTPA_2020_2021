/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.t4_sockets.servidor;

import com.mycompany.t4_sockets.comun.Validator;
import com.mycompany.t4_sockets.comun.exceptions.ProtocolFormatException;

/**
 *
 * @author Profesor
 */
public class ProtocolValidator 
        implements Validator
{

    @Override
    public void validar(String mensaje) throws ProtocolFormatException 
    {
        
        //@OPeracion@Operador1@Operador2
        if (mensaje != null)
        {
            String tokens[] = mensaje.split("@");
            if (tokens.length == 3)
            {
                if (
                    tokens[0].toLowerCase().equals("suma") ||
                    tokens[0].toLowerCase().equals("resta") ||
                    tokens[0].toLowerCase().equals("multiplica") ||
                    tokens[0].toLowerCase().equals("divide")
                        ){
                    try{
                        int op1 = Integer.parseInt(tokens[1]);
                        int op2 = Integer.parseInt(tokens[2]);
                        //---> Si llego a este punto comprobar que op1 y op2, estran dentro del rango
                        if (op1 < -100 || op1>100 || op2< -100 || op2>100){
                            throw new ProtocolFormatException();
                        }
                    }catch(Exception ex){
                        throw new ProtocolFormatException();
                    }
                }
                else{
                    throw new ProtocolFormatException();
                }
         
            }
            else{
                throw  new ProtocolFormatException();
            }
                    
        }
        
    }
    
    
}
