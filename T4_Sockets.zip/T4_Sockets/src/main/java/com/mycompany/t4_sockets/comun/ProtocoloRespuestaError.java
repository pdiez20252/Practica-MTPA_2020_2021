
package com.mycompany.t4_sockets.comun;


public class ProtocoloRespuestaError 
    extends ProtocoloRespuesta
{
    private String respuestaError;

    /**
     * @return the respuestaError
     */
    public String getRespuestaError() {
        return respuestaError;
    }

    /**
     * @param respuestaError the respuestaError to set
     */
    public void setRespuestaError(String respuestaError) {
        this.respuestaError = respuestaError;
    }
}
