
package com.mycompany.t4_sockets.comun;


public enum Operacion {
    SUMA,
    RESTA,
    MULTIPLICA,
    DIVIDE
}
