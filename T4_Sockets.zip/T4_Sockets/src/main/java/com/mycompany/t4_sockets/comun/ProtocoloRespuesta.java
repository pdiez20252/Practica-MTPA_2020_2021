
package com.mycompany.t4_sockets.comun;

/**
 * 
 * @Codigo@Mensaje|Resultado
 * 
 */

public abstract class ProtocoloRespuesta {
    private int codigo;
    //private String respuesta;

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
}




