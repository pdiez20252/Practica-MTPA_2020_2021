
package com.mycompany.t4_sockets.comun;

/**
 *
 * @OPERACION@OPERADOR1@OPERADOR2@
 * 
 * 
 */

public class ProtocoloPeticion 
{
    private Operacion operacion;
    
    private int operador1;
    private int operador2;
    
    

    /**
     * @return the operacion
     */
    public Operacion getOperacion() {
        return operacion;
    }

    /**
     * @param operacion the operacion to set
     */
    public void setOperacion(Operacion operacion) {
        this.operacion = operacion;
    }

    /**
     * @return the operador1
     */
    public int getOperador1() {
        return operador1;
    }

    /**
     * @param operador1 the operador1 to set
     */
    public void setOperador1(int operador1) {
        this.operador1 = operador1;
    }

    /**
     * @return the operador2
     */
    public int getOperador2() {
        return operador2;
    }

    /**
     * @param operador2 the operador2 to set
     */
    public void setOperador2(int operador2) {
        this.operador2 = operador2;
    }
    
}
