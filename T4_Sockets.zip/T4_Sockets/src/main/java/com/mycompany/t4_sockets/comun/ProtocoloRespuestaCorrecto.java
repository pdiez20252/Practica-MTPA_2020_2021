
package com.mycompany.t4_sockets.comun;


public class ProtocoloRespuestaCorrecto 
     extends ProtocoloRespuesta
{
    private int resultadoOperacion;

    /**
     * @return the resultadoOperacion
     */
    public int getResultadoOperacion() {
        return resultadoOperacion;
    }

    /**
     * @param resultadoOperacion the resultadoOperacion to set
     */
    public void setResultadoOperacion(int resultadoOperacion) {
        this.resultadoOperacion = resultadoOperacion;
    }
}

